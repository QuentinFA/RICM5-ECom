var myApp = angular.module('registApp', []);
myApp.controller('registController',function($http,$scoper){
	$scope.getAjaxUser=function(){

	}
})